declare module '@heroicons/react/outline' {

    export * from '@heroicons/react/outline/index';

}